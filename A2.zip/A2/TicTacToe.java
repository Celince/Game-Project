import javax.swing.JFrame;

/**
 * This program displays the TicTacToe game.
 * @author Celince Kapadia
 *
 */
public class TicTacToe{

	public static void main(String[] args) {
		
		JFrame frame = new BoardFrame();
		frame.setSize(530, 500);
		frame.setTitle("Tic Tac Toe Game");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}

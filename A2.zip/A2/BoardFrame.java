import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 * This is the BoardFrame class which extends JFrame and also implements ActionListener.
 * This class inherits methods from JFrame.This frame contains a panel that displays buttons
   for a TicTacToe game and a panel with a text field to record moves and a scoreboard to keep track of wins, losses
   and ties.
 * @author Celince Kapadia
 *
 */
public class BoardFrame extends JFrame implements ActionListener{

	private static final int FRAME_WIDTH = 700;
	private static final int FRAME_HEIGHT = 600;
	private JButton resetbutton;
	private JLabel p1ScoreLabel;
	private JTextArea p1ScoreDisplay;
	private JTextArea movehistory;
	private int p1Score;
	private JLabel p2ScoreLabel;
	private JTextArea p2ScoreDisplay;
	private int p2Score;
	private JLabel TieLabel;
	private JTextArea TieDisplay;
	private int TieScore;
	private int moveCount = 0;
	private boolean p1move = true;
	private final int rows = 1;
	private final int columns = 6;
	
	private JButton playermove [][] = new JButton [3][3];
	
	/**
	 * This is a constructor that adds several methods to the Board Frame.
	 */
	public BoardFrame()
		{	
		
		createButtonPanel();
		createScoreboard();
		MoveHistory();
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
	   }
	/**
	 * Creates a 3x3 button panel.
	 */
	private void createButtonPanel()
	   {
		JPanel buttonPanel = new JPanel();
	    buttonPanel.setLayout(new GridLayout(3, 3));
	    
	    for (int i = 0; i < playermove.length; i++) {
	        for (int j = 0; j < playermove[i].length; j++) {
	        	playermove[i][j] = new JButton();
	        	buttonPanel.add(playermove[i][j]);
	        	playermove[i][j].addActionListener(this);        	
	        }
	     }	    
	    add(buttonPanel, BorderLayout.CENTER);
	    }
	/**
	 * This method checks whether player1 or player2 wins and checks whether it is a tie. 
	 */
	public void checkWinOrTie() {
		if ((playermove[0][0].getText() == "1") && (playermove[0][1].getText() == "1") && (playermove[0][2].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[1][0].getText() == "1") && (playermove[1][1].getText() == "1") && (playermove[1][2].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[2][0].getText() == "1") && (playermove[2][1].getText() == "1") && (playermove[2][2].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[0][0].getText() == "1") && (playermove[1][0].getText() == "1") && (playermove[2][0].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[0][1].getText() == "1") && (playermove[1][1].getText() == "1") && (playermove[2][1].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[0][2].getText() == "1") && (playermove[1][2].getText() == "1") && (playermove[2][2].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[0][0].getText() == "1") && (playermove[1][1].getText() == "1") && (playermove[2][2].getText() == "1")) {
	           p1wins();
	       }
		else if ((playermove[0][2].getText() == "1") && (playermove[1][1].getText() == "1") && (playermove[2][0].getText() == "1")) {
	           p1wins();
	       }
		//p2
		else if ((playermove[0][0].getText() == "2") && (playermove[0][1].getText() == "2") && (playermove[0][2].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[1][0].getText() == "2") && (playermove[1][1].getText() == "2") && (playermove[1][2].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[2][0].getText() == "2") && (playermove[2][1].getText() == "2") && (playermove[2][2].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[0][0].getText() == "2") && (playermove[1][0].getText() == "2") && (playermove[2][0].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[0][1].getText() == "2") && (playermove[1][1].getText() == "2") && (playermove[2][1].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[0][2].getText() == "2") && (playermove[1][2].getText() == "2") && (playermove[2][2].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[0][0].getText() == "2") && (playermove[1][1].getText() == "2") && (playermove[2][2].getText() == "2")) {
	           p2wins();
	       }
		else if ((playermove[0][2].getText() == "2") && (playermove[1][1].getText() == "2") && (playermove[2][0].getText() == "2")) {
	           p2wins();
	       }
		else if (moveCount==9){
			tie();
		}
	}
	/**
	 * This method checks when player 1 wins, update the scoreboard and show a message dialog that Player 1 has won.
	 */
	public void p1wins() {
		for (int i = 0; i < playermove.length; i++) {
	        for (int j = 0; j < playermove[i].length; j++) {
	        	playermove[i][j].setEnabled(false);
	        }
	     }
		p1Score++;
		p1ScoreDisplay.setText(String.valueOf(p1Score));
		movehistory.append("Player 1 wins\n");
		JOptionPane.showMessageDialog(null, "Player 1 wins", "Winner", JOptionPane.INFORMATION_MESSAGE);	
	}
	/**
	 * This method checks when player 2 wins, update the scoreboard and show a message dialog that Player 2 has won.
	 */
	public void p2wins() {
		for (int i = 0; i < playermove.length; i++) {
	        for (int j = 0; j < playermove[i].length; j++) {
	        	playermove[i][j].setEnabled(false);
	        }
	     }
		p2Score++;
		p2ScoreDisplay.setText(String.valueOf(p2Score));
		movehistory.append("Player 2 wins\n");
    	JOptionPane.showMessageDialog(null, "Player 2 wins", "Winner", JOptionPane.INFORMATION_MESSAGE);
	}
	/**
	 * This method checks when there is a tie, update the scoreboard and show a message dialog that there is a tie.
	 */
	public void tie() {
		for (int i = 0; i < playermove.length; i++) {
	        for (int j = 0; j < playermove[i].length; j++) {
	        	playermove[i][j].setEnabled(false);
	        }
	     }
		TieScore++;
		TieDisplay.setText(String.valueOf(TieScore));
		movehistory.append("It's a tie\n");
    	JOptionPane.showMessageDialog(null, "Tie!", "Outcome", JOptionPane.INFORMATION_MESSAGE);
	}
	/**
	 * This method creates the scoreboard adding in a reset button, player 1 score display, player 2 score display
	 * and tie display. 
	 */
	private void createScoreboard() {
		resetbutton = new JButton("reset");
		resetbutton.addActionListener(this);
		this.setVisible(true);
		
		
		p1ScoreLabel = new JLabel("Player 1: ");
		p1ScoreDisplay = new JTextArea(rows,columns);
		p1ScoreDisplay.append(p1Score + "");
		p1ScoreDisplay.setEditable(false);
		
		p2ScoreLabel = new JLabel("Player 2: ");
		p2ScoreDisplay = new JTextArea(rows,columns);
		p2ScoreDisplay.append(p2Score + "");
		p2ScoreDisplay.setEditable(false);
		
		
		TieLabel = new JLabel("Tie: ");
		TieDisplay = new JTextArea(rows,columns);
		TieDisplay.append(TieScore + "");
		TieDisplay.setEditable(false);
		JPanel scoreboard = new JPanel();
		
		scoreboard.add(resetbutton);
		scoreboard.add(p1ScoreLabel);
		scoreboard.add(p1ScoreDisplay);
		scoreboard.add(p2ScoreLabel);
		scoreboard.add(p2ScoreDisplay);
		scoreboard.add(TieLabel);
		scoreboard.add(TieDisplay);
		add(scoreboard, BorderLayout.NORTH);
		
	}
	/**
	 * This method creates a JTextArea to show history of all the moves made.
	 */
	private void MoveHistory() {
		movehistory = new JTextArea(20,12);
		movehistory.setEditable(false);
		JScrollPane scroll = new JScrollPane (movehistory);
		
		add(scroll, BorderLayout.EAST);
	}
	/**
	 * When a button is pressed actionPerformed method is called and if it is player 1's turn player 1 goes first then player 2
	 * and updates the buttons text until a winning, loosing or tie condition is met. This method also adds the moves into the
	 * JTextArea and resets the game by pressing the reset button. 
	 */
	public void actionPerformed(ActionEvent event) {
		for (int i = 0; i < playermove.length; i++) {
	        for (int j = 0; j < playermove[i].length; j++) {
	        	if (event.getSource()==playermove[i][j]) {
	        		if (p1move) {
	        			if (playermove[i][j].getText()=="") {
		        			playermove[i][j].setText("1");
		        			p1move = false;
		        			moveCount++;
		        			movehistory.append("Player 1: ("+String.valueOf(i+1)+","+String.valueOf(j+1)+")"+"\n");
		        			checkWinOrTie();
		        			
		        		}
	        			else if (playermove[i][j].getText()=="2") {
	        				JOptionPane.showMessageDialog(null, "Space already occupied by player 2", "Oops", JOptionPane.INFORMATION_MESSAGE);
	        			}
	        			else if (playermove[i][j].getText()=="1") {
	        				JOptionPane.showMessageDialog(null, "Space already occupied by player 1", "Oops", JOptionPane.INFORMATION_MESSAGE);
	        			}
	        		}
	        		else {
		        		if (playermove[i][j].getText()=="") {
		        			playermove[i][j].setText("2");
		        			p1move = true;
		        			moveCount++;
		        			movehistory.append("Player 2: ("+String.valueOf(i+1)+","+String.valueOf(j+1)+")"+"\n");
		        			checkWinOrTie();
		        			
		        		}
		        		else if (playermove[i][j].getText()=="2") {
	        				JOptionPane.showMessageDialog(null, "Space already occupied by player 2", "Oops", JOptionPane.INFORMATION_MESSAGE);
	        			}
		        		else if (playermove[i][j].getText()=="1") {
	        				JOptionPane.showMessageDialog(null, "Space already occupied by player 1", "Oops", JOptionPane.INFORMATION_MESSAGE);
	        			}
		        	}
	        	}
	        }
	    }
			
		if (event.getSource()== resetbutton) {
			for (int i = 0; i < playermove.length; i++) {
		        for (int j = 0; j < playermove[i].length; j++) {
		        	playermove[i][j].setText("");
		        	moveCount = 0;
		        	playermove[i][j].setEnabled(true);
		        	p1move= true;
		        }		        
		    }
			MoveHistory();
			movehistory.append("Board Resets\n");
		}	
    }	
}
